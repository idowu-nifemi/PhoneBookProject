# **PhoneBookProject
so this project is basically about CRUD mechanism 
users can sign up ,login ,create ,retrieve, delete and update data that is unique to them.
