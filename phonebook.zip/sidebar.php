<!DOCTYPE html>
<html>
  
    <div id="sidebar"  onclick ="togglemenu()">
        <!-- <div class="toggle-btn">
                <span></span>
                <span></span>
                <span></span>
        </div> -->
        <ul>
          <a href="dashboard.php"><i class="fa fa-fw fa-envelope"></i> Dashboard</a>
          <a href="view_contact.php"><i class="fa fa-fw fa-user"></i>contacts</a>
          <a href="#about"><i class="fa fa-fw fa-question"></i>About</a>
          <a href="signout.php"><i class="fa fa-fw fa-trash"></i>logout</a>
        </ul>
    </div>
</html> 